/*
 * Paulo Pedreiras
 * Miguel Cabral
 * Diogo Vicente, Sept/2021
 * FREERTOS demo for ChipKit MAX32 board
 * - Creates two periodic tasks
 * - One toggles Led LD4, other is a long (interfering)task that 
 *      activates LD5 when executing 
 * - When the interfering task has higher priority interference becomes visible
 *      - LD4 does not blink at the right rate
 *
 * Environment:
 * - MPLAB X IDE v5.45
 * - XC32 V2.50
 * - FreeRTOS V202107.00
 *
 *
 */

/* Standard includes. */
#include <stdio.h>
#include <string.h>

#include <xc.h>

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"


/* App includes */
#include "../UART/uart.h"
#include "semphr.h" 

/* Set the tasks' period (in system ticks) */
#define LED_FLASH_PERIOD_MS 	( 250 / portTICK_RATE_MS ) 
#define INTERF_PERIOD_MS 	( 3000 / portTICK_RATE_MS )
#define ACQ_PERIOD_MS     (100 / portTICK_RATE_MS)

/* Control the load task execution time (# of iterations)*/
/* Each unit corresponds to approx 50 ms*/
#define INTERF_WORKLOAD          ( 20)

/* Priorities of the demo application tasks (high numb. -> high prio.) */
#define PROC_PRIORITY	( tskIDLE_PRIORITY + 1)
#define CONVERT_PRIORITY	    ( tskIDLE_PRIORITY + 2)
#define ACQ_PRIORITY	    ( tskIDLE_PRIORITY + 3)

/* Global variables*/
float res;
int avg = 0;
SemaphoreHandle_t xSemaphore1, xSemaphore2;

/*
 * Prototypes and tasks
 */



void vDataAqc(void *pvParam)
{
    uint8_t msg [80];
     // Variable declarations;
    TickType_t xLastWakeTime;
    xLastWakeTime = xTaskGetTickCount();
    const TickType_t xFrequency = portTICK_PERIOD_MS*(ACQ_PERIOD_MS);
   
    if(xSemaphore1 != NULL){
    // Main loop
        while (1) {
            vTaskDelayUntil(&xLastWakeTime,xFrequency);
            // Get one sample
            IFS1bits.AD1IF = 0; // Reset interrupt flag
            AD1CON1bits.ASAM = 1; // Start conversion
            while (IFS1bits.AD1IF == 0); // Wait fo EOC

            // Convert to 0..3.3V 
            res = (ADC1BUF0 * 3.3) / 1023;
            res = (res * 100) / 3.3;
            
            xSemaphoreGive(xSemaphore1);

        }
    }

}
 

void vDataProc(void *pvParam)
{
  
    double sum = 0.0;
    double a[5] = {0,0,0,0,0};

    
    if( xSemaphore1 != NULL && xSemaphore2 != NULL )
    {
        while(1){
           
           
            /* See if we can obtain the semaphore.  If the semaphore is not
            available wait 10 ticks to see if it becomes free. */
            if( xSemaphoreTake( xSemaphore1, ( TickType_t ) 10 ) == pdTRUE )
            {
                /* We were able to obtain the semaphore and can now access the
                shared resource. */
                
                a[1] = a[0];
                a[2] = a[1];
                a[3] = a[2];
                a[4] = a[3];
                a[0] = res;
               
                for(int i = 0; i < 5; i++){
                    sum += a[i]; 
                }
                avg =(int) sum/5;
                sum = 0;
                /* We have finished accessing the shared resource.  Release the
                semaphore. */
     
                xSemaphoreGive( xSemaphore2);
            }
            else
            {
                /* We could not obtain the semaphore and can therefore not access
                the shared resource safely. */
            }
        }
    }
 
}

void vDataConvert(void *pvParam)
{
    uint8_t msg [80];
  
    if( xSemaphore2 != NULL )
    {
        while(1){
            /* See if we can obtain the semaphore.  If the semaphore is not
            available wait 10 ticks to see if it becomes free. */
            if( xSemaphoreTake( xSemaphore2, ( TickType_t ) 10 ) == pdTRUE )
            {
                /* We were able to obtain the semaphore and can now access the
                shared resource. */
                sprintf(msg,"AERAGE OF LAST 5 TEMPERATURE SAMPLES: %d\n\r",avg);
                PrintStr(msg);    
   
            }
            else
            {
                /* We could not obtain the semaphore and can therefore not access
                the shared resource safely. */
            }
        }
    }
 
}


/*
 * Create the demo tasks then start the scheduler.
 */
int mainA3( void )
{
    
    // Set RA3 (LD4) and RC1 (LD5) as outputs
    TRISAbits.TRISA3 = 0;
    TRISCbits.TRISC1 = 0;
    PORTAbits.RA3 = 0;
    PORTCbits.RC1 = 0;
    
    
	// Init UART and redirect stdin/stdot/stderr to UART
    if(UartInit(configPERIPHERAL_CLOCK_HZ, 115200) != UART_SUCCESS) {
        PORTAbits.RA3 = 1; // If Led active error initializing UART
        while(1);
    }

     __XC_UART = 1; /* Redirect stdin/stdout/stderr to UART1*/
    
       
    // Disable JTAG interface as it uses a few ADC ports
    DDPCONbits.JTAGEN = 0;
    
    // Initialize ADC module
    // Polling mode, AN0 as input
    // Generic part
    AD1CON1bits.SSRC = 7; // Internal counter ends sampling and starts conversion
    AD1CON1bits.CLRASAM = 1; //Stop conversion when 1st A/D converter interrupt is generated and clears ASAM bit automatically
    AD1CON1bits.FORM = 0; // Integer 16 bit output format
    AD1CON2bits.VCFG = 0; // VR+=AVdd; VR-=AVss
    AD1CON2bits.SMPI = 0; // Number (+1) of consecutive conversions, stored in ADC1BUF0...ADCBUF{SMPI}
    AD1CON3bits.ADRC = 1; // ADC uses internal RC clock
    AD1CON3bits.SAMC = 16; // Sample time is 16TAD ( TAD = 100ns)
    // Set AN0 as input
    AD1CHSbits.CH0SA = 0; // Select AN0 as input for A/D converter
    TRISBbits.TRISB0 = 1; // Set AN0 to input mode
    AD1PCFGbits.PCFG0 = 0; // Set AN0 to analog mode
    // Enable module
    AD1CON1bits.ON = 1; // Enable A/D module (This must be the ***last instruction of configuration phase***)
   
    
    /* Welcome message*/
    printf("\n\n *********************************************\n\r");
    printf("Starting TEMPERATURE ACQ FreeRTOS Demo - A3 APP \n\r");
    printf("*********************************************\n\r");
    
    // Semaphores
    
    xSemaphore1 = xSemaphoreCreateBinary();
    xSemaphore2 = xSemaphoreCreateBinary();
      
    /* Create the tasks defined within this file. */
	
    xTaskCreate( vDataAqc, ( const signed char * const ) "Acq", configMINIMAL_STACK_SIZE, NULL, ACQ_PRIORITY, NULL );
    xTaskCreate( vDataProc, ( const signed char * const ) "Proc", configMINIMAL_STACK_SIZE, NULL, PROC_PRIORITY, NULL );
    xTaskCreate( vDataConvert, ( const signed char * const ) "Convert", configMINIMAL_STACK_SIZE, NULL, CONVERT_PRIORITY, NULL );
        /* Finally start the scheduler. */
	vTaskStartScheduler();

	/* Will only reach here if there is insufficient heap available to start
	the scheduler. */
	return 0;
}
